function chamarServicoAPITempo() {
  const apiKey = "7e77dedf307c4133e4fa28567b872554";
  const cidade = document.getElementById("cidade").value;
  const pais = document.getElementById("pais").value;

  if (!cidade) {
    alert("Digite uma cidade");
    return;
  }

  if (!pais) {
      alert("Digite um país");
    return;
  }
  const urlClima = `https://api.openweathermap.org/data/2.5/weather?q=${cidade},${pais}&appid=${apiKey}&lang=pt_br`;
  fetch(urlClima)
    .then((response) => response.json())
    .then((data) => {
      const tempo = data.main.temp;
      const tempoCelsius = tempo - 273.15;
      const description = data.weather[0].description;
      const cidade = data.name;
      document.getElementById(
        "cidade-resultado"
      ).innerHTML = `<h2>Cidade: ${cidade}</h2>`;
      document.getElementById(
        "pais-resultado"
      ).innerHTML = `<h3>País: ${pais}</h3>`;
      document.getElementById("tempo").innerHTML = `Temperatura: ${Math.trunc(
        tempoCelsius
      )} °C`;
      document.getElementById(
        "descricao"
      ).innerHTML = `Descrição: ${description}`;
    })
    .catch((error) => {
      console.error("Erro ao consultar a API:", error);
      alert("Erro ao consultar a API");
    });
}
