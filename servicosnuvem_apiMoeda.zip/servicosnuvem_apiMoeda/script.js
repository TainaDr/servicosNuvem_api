function converterMoedas() {
    const moedaOrigem = document.getElementById("moedaOrigem").value.toUpperCase();
    const moedaDestino = document.getElementById("moedaDestino").value.toUpperCase();
    const valorStr = document.getElementById("valor").value;
    const valor = parseFloat(valorStr);

    if (isNaN(valor)) {
        alert('Valor inválido. Insira um número válido.');
        return;
    }

    if (moedaOrigem === "" || moedaDestino === "" || valorStr === "") {
        alert("Informe as moedas de origem e destino e o valor.");
        return;
    }

    const appId = "476befdedf5244caadb23d121e8cdff8";
    const urlAPI = `https://openexchangerates.org/api/latest.json?app_id=${appId}`;

    fetch(urlAPI)
        .then(response => {
            if (response.ok) {
                return response.json();
            } else {
                throw new Error(`Erro na requisição: ${response.status}`);
            }
        })
        .then((data) => {
            const taxaOrigem = data.rates[moedaOrigem];
            const taxaDestino = data.rates[moedaDestino];

            if (typeof taxaOrigem !== 'number' || typeof taxaDestino !== 'number') {
                throw new Error(`Taxa de conversão inválida para ${moedaOrigem} ou ${moedaDestino}`);
            }

            const valorConvertido = (valor * (taxaDestino / taxaOrigem)).toFixed(2);
            const div_dados = document.getElementById("dados");
            div_dados.innerHTML = `
                <p>Valor de Origem: ${valor} ${moedaOrigem}</p>
                <p>Valor Convertido: ${valorConvertido} ${moedaDestino}</p>
            `;
        })
        .catch(error => {
            alert("Erro ao requisitar o serviço na nuvem!");
            console.error("Erro ao requisitar o serviço na nuvem", error);
        });
}